import socket
import pickle

def serverInitSocket(ip='127.0.0.1', port=12345):
    serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    serverSocket.bind((ip, port))
    serverSocket.listen(10)
    print("Waiting for clients to connect")
    return serverSocket


def serverWaitForNewClient(serverSocket:socket):
    clientSocket, clientAddress = serverSocket.accept()
    print(f"Connected with client, ip: {clientAddress[0]} port: {clientAddress[1]}")
    return clientSocket


def serverSendString(clientSocket:socket, mess:str):
    utfencodedmsg = mess.encode('utf-8')
    clientSocket.send(utfencodedmsg)


def serverRecvPlanet(clientSocket:socket):
    planetpickle = clientSocket.recv(4096)
    planet = pickle.loads(planetpickle)

    return planet

def clientInitSocket(ip='127.0.0.1', port=12345):
    clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    clientSocket.connect((ip, port))
    return clientSocket

def clientRecvString(clientSocket:socket):
    message = ''
    data = clientSocket.recv(64)
    message += data.decode()
    return message

def clientSendPlanet(clientSocket:socket, p:object):
    planetpickle = pickle.dumps(p)
    clientSocket.send(planetpickle)
