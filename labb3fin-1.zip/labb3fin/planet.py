#Module for planet class for DVA248 Datorsystem
#
#   author: Dag Nyström, 2023
#

import socket

class planet:
    name:str
    sx:float
    sy:float
    vx:float
    vy:float
    mass:float
    life:int
    cSock:socket #ONLY USED BY SERVER

    def __init__(self,name, sx, sy,vx,vy,mass,life):
        self.name=name
        self.sx=sx
        self.sy=sy
        self.vx=vx
        self.vy=vy
        self.mass=mass
        self.life=life
        self.cSock=None

    def serverAddClientSock(self,cSock):
        self.cSock=cSock

    #ONLY USED BY SERVER, do not send socket from client to server.
    def serverGetClientSock(self):
        return self.cSock