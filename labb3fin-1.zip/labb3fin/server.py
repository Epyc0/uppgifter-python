
import threading
import time
from space import space
from cscomm import serverInitSocket,serverWaitForNewClient,serverRecvPlanet,serverSendString
from planet import planet
from math import sqrt


WindowX=1000
WindowY=700

class universe:

    locker = threading.Lock()

    planet_list=[]
    DT : int
    name_counter = 0

    def __init__(self, dt=10):
        self.planet_list.clear()
        self.DT=dt


    def add_planet(self, p: planet):
        self.locker.acquire()
        self.name_counter += 1
        self.planet_list.append(p)
        self.locker.release()


    def remove_planet(self, p: planet):
        self.locker.acquire()
        self.planet_list.remove(p)
        self.locker.release()

    def calculate_planet_pos(self,p:planet):

        Atotx = 0.0
        Atoty = 0.0
        x = 0.0
        y = 0.0
        r = 0.0
        a = 0.0
        ax = 0.0
        ay = 0.0

        G = 6.67259 * pow(10, -11)
        cur:planet

        self.locker.acquire()
        for cur in self.planet_list:
            if (cur!=p):

                x = cur.sx-p.sx
                y=cur.sy-p.sy

                r = sqrt(pow(x, 2) + pow(y, 2))

                cur.mass = cur.mass + 1
                r = r + 1
                a = G * (cur.mass / pow(r, 2))

                ay = a * (y / r)
                ax = a * (x / r)

                Atotx += ax
                Atoty += ay
        p.vx = p.vx + (Atotx * self.DT)
        p.vy = p.vy + (Atoty * self.DT)
        p.sx = p.sx + (p.vx * self.DT)
        p.sy = p.sy + (p.vy * self.DT)

        p.life -= 1
        self.locker.release()


def drawPlanets(u, s):
    while True:
        u.locker.acquire()
        for p in u.planet_list:
            s.putPlanet(int(p.sx), int(p.sy), rad=2.5, color="white")
        u.locker.release()
        time.sleep(0.001)

def serverThread(u):
    serverSocket = serverInitSocket()
    while True:
        clientSocket = serverWaitForNewClient(serverSocket)
        threading.Thread(target=clientThread, daemon=True,args=(clientSocket,u)).start()

def clientThread(clientSocket,u):
    while True:
        try:
            planet = serverRecvPlanet(clientSocket)
            u.add_planet(planet)
            mess = 'Planet received by the server.'
            serverSendString(clientSocket, mess)
            time.sleep(.0001)

            threading.Thread(target=planetThread,daemon=True,args=(clientSocket,u,planet)).start()
        except:
            pass


def planetThread(clientSocket,u,planet):
    while True:

        u.calculate_planet_pos(planet)

        if (planet.sx > WindowX or planet.sx < -WindowX or planet.sy > WindowY or planet.sy < -WindowY):
            mess = f' {planet.name} escaped from the game window'
            u.remove_planet(planet)
            serverSendString(clientSocket, mess)
            break

        if planet.life <= 0:
            u.remove_planet(planet)
            mess = f"Your {planet.name} has died of death "
            serverSendString(clientSocket, mess)
            break
        time.sleep(0.00001)

def main():
    u = universe()
    s = space(WindowX, WindowY)
    threading.Thread(target=drawPlanets, daemon=True, args=(u,s)).start()
    threading.Thread(target=serverThread, daemon=True, args=(u,)).start()
    s.mainLoop()

if __name__== "__main__":
    main()

