import time

grid = []
gridqueue = []


def validator(grid, row, col, num):
    for i in range(9):
        if grid[row][i] == num or grid[i][col] == num:
            return False

    boxrow = (row // 3) * 3
    boxcol = (col // 3) * 3

    for i in range(boxrow, boxrow + 3):
        for j in range(boxcol, boxcol + 3):
            if grid[i][j] == num:
                return False
    return True

def solve(grid, y=0, x=0):
    if y == 9:
        return True
    if x == 9:
        return solve(grid, y + 1, 0)
    if not grid[y][x] == 0:
        return solve(grid, y, x + 1)
    else:
        for v in range(1, 10):
            if validator(grid, y, x, v):
                grid[y][x] = v
                if solve(grid, y, x + 1):
                    return True
                grid[y][x] = 0
        return False

def main():
    solve(grid)

def gridmaker():
    grid.clear()

    with open('soduk1.txt', 'r') as f:
        file = f.read()

    rows = file.strip().split('\n')

    for row in rows:
        rownum = [int(num) for num in row]
        gridqueue.append(rownum)
    i = 0
    for row in gridqueue:
        if i < 9:
            i = i+1
            item = gridqueue.pop(0)
            grid.append(item)
        else:
            break



if __name__ == "__main__":
    start = time.time()
    for x in range(1,10):
        gridmaker()
        main()
        print('Sudoku', x)
        print(*grid, sep='\n')

    end = time.time()
    print(end - start, "s")


