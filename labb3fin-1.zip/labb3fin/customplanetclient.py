import threading
from planet import planet
from cscomm import clientInitSocket, clientRecvString, clientSendPlanet

def createplanet(p,):
    socket = clientInitSocket()
    clientSendPlanet(socket,p)
    for i in range(2):
        message = clientRecvString(socket)
        print(message)



while True:

    name = input('Input planet name')
    sx = int(input('input x pos'))
    sy = int(input('input y pos'))
    vx = float(input('input x acceleration'))
    vy = float(input('input y acceleration'))
    mass = float(input('input mass'))
    Life = float(input('input life'))

    p = planet(name, sx, sy, vx, vy, mass, Life)
    threading.Thread(target=createplanet(p),args=(p,)).start()
    input()





