import threading
from planet import planet
from cscomm import clientInitSocket, clientRecvString, clientSendPlanet

def createplanet(p,):
    socket = clientInitSocket()
    clientSendPlanet(socket,p)
    for i in range(2):
        message = clientRecvString(socket)
        print(message)



while True:
    name = "sun"
    sx = 300
    sy = 300
    vx = 0
    vy = 0
    mass = float(1e8)
    Life = float(10e8)

    p = planet(name, sx, sy, vx, vy, mass, Life)

    thread = threading.Thread(target=createplanet(p),args=(p,)).start()
    input()


